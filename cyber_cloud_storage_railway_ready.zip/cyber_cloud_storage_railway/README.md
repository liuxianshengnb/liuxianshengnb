# Cyber Cloud Storage - Railway 可部署版

这是已经适配 Railway 的后端云存储项目。

## 默认登录

账号：`luoshanjinb`

密码：`123456`

## Railway 必填变量

在 Railway 的 Variables 里添加：

```env
PORT=3000
JWT_SECRET=换成一个很长很随机的字符串
ADMIN_USERNAME=luoshanjinb
ADMIN_PASSWORD=123456
MAX_FILE_SIZE_MB=200
DATA_DIR=/data
```

## Railway Volume

一定要添加 Volume：

```text
Mount Path: /data
```

这样上传文件会保存到：

```text
/data/uploads
```

文件数据库保存到：

```text
/data/files.json
```

## 部署方式

1. 解压这个项目
2. 上传到 GitHub
3. Railway → New Project → Deploy from GitHub repo
4. 添加 Variables
5. 添加 Volume，Mount Path 填 `/data`
6. Redeploy
7. Generate Domain 后访问网页

## 本地运行

```bash
npm install
cp .env.example .env
npm start
```

打开：

```text
http://localhost:3000
```

## 重要说明

Railway 如果不添加 Volume，文件不会可靠长期保存。这个版本已经把后端改成读取 `DATA_DIR`，所以只要 Railway 设置 `DATA_DIR=/data` 并挂载 Volume 到 `/data`，就可以持久保存上传文件。
