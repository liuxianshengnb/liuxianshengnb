const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const multer = require("multer");
const jwt = require("jsonwebtoken");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
require("dotenv").config();

const app = express();

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "change_this_secret";
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "luoshanjinb";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "123456";
const MAX_FILE_SIZE_MB = Number(process.env.MAX_FILE_SIZE_MB || 200);

// Railway Volume 适配：Railway 上设置 DATA_DIR=/data，Volume 挂载路径也设置 /data
const ROOT_DIR = __dirname;
const DATA_DIR = process.env.DATA_DIR || ROOT_DIR;
const PUBLIC_DIR = path.join(ROOT_DIR, "public");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const DB_FILE = path.join(DATA_DIR, "files.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]", "utf-8");

app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(PUBLIC_DIR));

const loginLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 12,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "登录请求太频繁，请稍后再试。" }
});

function readDb() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
  } catch {
    return [];
  }
}

function writeDb(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
}

function safeName(name) {
  return String(name || "file")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
    .replace(/\s+/g, " ")
    .slice(0, 180);
}

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";

  if (!token) {
    return res.status(401).json({ error: "未登录。" });
  }

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "登录已过期，请重新登录。" });
  }
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || "");
    const id = crypto.randomUUID();
    cb(null, `${id}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: MAX_FILE_SIZE_MB * 1024 * 1024,
    files: 20
  }
});

app.post("/api/login", loginLimiter, (req, res) => {
  const { username, password } = req.body || {};

  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "账号或密码错误。" });
  }

  const token = jwt.sign(
    { username: ADMIN_USERNAME },
    JWT_SECRET,
    { expiresIn: "7d" }
  );

  res.json({ token, username: ADMIN_USERNAME });
});

app.get("/api/me", auth, (req, res) => {
  res.json({ username: req.user.username });
});

app.get("/api/files", auth, (_req, res) => {
  const files = readDb()
    .filter(item => fs.existsSync(path.join(UPLOAD_DIR, item.storedName)))
    .sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));

  res.json({ files });
});

app.post("/api/upload", auth, upload.array("files", 20), (req, res) => {
  const uploaded = (req.files || []).map(file => ({
    id: crypto.randomUUID(),
    originalName: safeName(file.originalname),
    storedName: file.filename,
    mimeType: file.mimetype || "application/octet-stream",
    size: file.size,
    uploadedAt: new Date().toISOString()
  }));

  const db = readDb();
  db.push(...uploaded);
  writeDb(db);

  res.json({ files: uploaded });
});

app.get("/api/download/:id", auth, (req, res) => {
  const db = readDb();
  const item = db.find(file => file.id === req.params.id);

  if (!item) {
    return res.status(404).json({ error: "文件不存在。" });
  }

  const filePath = path.join(UPLOAD_DIR, item.storedName);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: "服务器文件已丢失。" });
  }

  res.download(filePath, item.originalName);
});

app.delete("/api/files/:id", auth, (req, res) => {
  const db = readDb();
  const item = db.find(file => file.id === req.params.id);

  if (!item) {
    return res.status(404).json({ error: "文件不存在。" });
  }

  const filePath = path.join(UPLOAD_DIR, item.storedName);

  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }

  writeDb(db.filter(file => file.id !== req.params.id));
  res.json({ ok: true });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: `上传失败：${err.message}` });
  }

  console.error(err);
  res.status(500).json({ error: "服务器错误。" });
});

app.listen(PORT, () => {
  console.log(`Cyber Cloud Storage running on port ${PORT}`);
  console.log(`DATA_DIR: ${DATA_DIR}`);
  console.log(`UPLOAD_DIR: ${UPLOAD_DIR}`);
});
